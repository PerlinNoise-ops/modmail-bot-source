class PluginInstallationError extends Error {}

module.exports = {
  PluginInstallationError,
};
